# __init__.py
from .version import __version__
from .azure_strg_utils import AzureStorageUtils